'''
import matplotlib.pyplot as plt
plt.plot([2,3,4,5,1,6])
plt.ylabel("Grade")
plt.ylabel("number")
plt.axis([-1,11,0,7])
plt.savefig('test',dpi=200)#plt.savefig()将输出图形存储为文件，默认为png格式，可以通过dpi修改输出质量
'''
import pandas as pd
import requests
import matplotlib
from matplotlib.font_manager import *

import json
import numpy as np
from matplotlib import pyplot as plt
url='https://bj.lianjia.com/fangjia/priceTrend/?region=city&region_id=110000'

dictdata=json.loads(requests.get(url).text)
MonthList=dictdata.get('currentLevel').get('month')
print(MonthList)
Content=MonthList.index('12月')
for index,vlue in enumerate(MonthList):
    if index<=Content:
        newMonth=[('2017-'+i.strip('月')) for i in MonthList[:Content+1]]
    else:
        newMonth.extend(['2018-'+i.strip('月') for i in MonthList[Content+1:]])
        break;
print(newMonth)


GuaipaiJia=dictdata.get('currentLevel').get('listPrice').get('total')
CankaoJIa=dictdata.get('currentLevel').get('dealPrice').get('total')
print(GuaipaiJia)
print(GuaipaiJia)
# plt.rcParams['font.sans-serif'] = ['SimHei']
# plt.rcParams['font.family']='sans-serif'
# #解决负号'-'显示为方块的问题
# plt.rcParams['axes.unicode_minus'] = False


plt.xticks(range(len(newMonth)),newMonth)
plt.xticks(rotation=30)
plt.plot(range(len(GuaipaiJia)),GuaipaiJia)
plt.plot(CankaoJIa, color='red', linewidth=1.0, linestyle='--')
plt.xlabel('Month')
plt.ylabel('price')

plt.title('beijing fangjia')

plt.savefig('../static/images/fangjia.png',dpi=300)

plt.show()

plt.close()
#/Users/finup/Downloads/weuruan/msyhbd.ttf