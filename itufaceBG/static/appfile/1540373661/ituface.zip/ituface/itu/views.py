from prettytable import PrettyTable
from django.shortcuts import render
from itu.models import Students2
from django.core.paginator import Paginator,EmptyPage, PageNotAnInteger


def SelectSql(request):
    results=Students2.objects.all()

    paginator=Paginator(results,10)
    page=request.GET.get('page',1)
    currentPage=int(page)
    try:
        print(page)
        result=paginator.page(page)
    except PageNotAnInteger:
        result=paginator.page(1)
    except EmptyPage:
        result=paginator.page(paginator.num_pages)


    return render(request,'index.html',{'SelectSql':result,'page':str,'paginator':paginator,'Sid':'1'})





# Create your views here.
