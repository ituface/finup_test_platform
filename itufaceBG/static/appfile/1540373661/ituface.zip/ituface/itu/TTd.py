dicts={'create_time': ['', '']}
print((dicts.get('create_time')))

a=[111,1,2,3,4,4,4,5,6,7]
print(set(a))
for i in dicts.get('create_time'):
    if i=='':
        continue
