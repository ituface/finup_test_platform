from django.apps import AppConfig


class ItuConfig(AppConfig):
    name = 'itu'
