from itu.Errror import PasswodException
from django.shortcuts import redirect, render
from django.http import QueryDict
from django.core.handlers.wsgi import WSGIRequest
import xml.etree.ElementTree as ET
tree=ET.parse('./mysql_xml/select_web.xml')
root = tree.getroot()
select=root.findall('select')
getXmlSql=lambda a:''.join([i.text for i in select if i.get("id")==a]).strip()
# 当cookie过期后回到登录界面
def Check_login(func):
    def inner(request, *args, **kwargs):
        if request.COOKIES.get('username') == None:
            return redirect('/login/')
        return func(request, *args, **kwargs)

    return inner


# 判断request传值是否有空的字段

def requestFound(func):
    def inner(request, *args, **kwargs):
        if request.method == 'post':
            dicts = dict(request.POST)
            for i in dicts.keys():
                if dicts[i] is None:
                    del dicts[i]


# 通过SqlStatement解析xml 获取sql语句，然后通过request.POST传回
def get_web_input_data(SqlStatement):
    def outer(func):
        def inner(request, *args, **kwargs):
            sql=getXmlSql(SqlStatement)#获取sql语句
            if request.method == 'POST':
                accept_data = dict(request.POST)
                del accept_data['csrfmiddlewaretoken']
                for i in list(accept_data.keys()):
                    if ''.join(accept_data[i]) == '':
                        del accept_data[i]
                sql_data = []
                sql_data.append(sql)
                sql_data.append('where 1=1')
                #通过for循环把前端传过来的判断添加到sql里
                for key in accept_data.keys():
                    if key=='create_time':
                        continue
                    sql_data.append('and')
                    sql_data.append(key)
                    sql_data.append('=')
                    sql_data.append("'%s'"%''.join(accept_data[key]))
                sql = ' '.join(sql_data)
            request.POST = QueryDict('sql=%s' % sql)

            return func(request, *args, **kwargs)

        return inner

    return outer
# def createTimeanage(func):
#     def inner(request,*args,**kwargs):
#         if request.method=='POST':
#             data=dict(request.POST)
#         createtime=data.get('create_time')
#         if createtime[0]!='':
#             data='create_time>"%s"'%createtime[0]
#         if createtime[1]!='':
#             data='create_time<"%s"'%createtime[1]
#
