class PasswodException(Exception):
    def __init__(self):
        super().__init__()
    def __str__(self):
        return '密码错误'