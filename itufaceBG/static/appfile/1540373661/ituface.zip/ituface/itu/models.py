from django.db import models



class Students2(models.Model):
    id = models.IntegerField(primary_key=True)
    user = models.CharField(max_length=10, blank=True, null=True)
    password = models.CharField(max_length=20, blank=True, null=True)


    class Meta:
        managed = False
        db_table = 'students2'

class Data(models.Model):
        id = models.BigAutoField(primary_key=True)
        user = models.ForeignKey('Students2', models.DO_NOTHING, blank=True, null=True)
        create_time = models.DateTimeField(blank=True, null=True)
        upate_time = models.DateTimeField(blank=True, null=True)
        data = models.CharField(max_length=20, blank=True, null=True)
        host = models.CharField(max_length=20, blank=True, null=True)

        class Meta:
            managed = False
            db_table = 'data'

# Create your models here.
