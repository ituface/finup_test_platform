from django.shortcuts import render, HttpResponseRedirect, render_to_response, HttpResponse, redirect
from itu.models import Students2, Data
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.http import HttpResponse, HttpResponseRedirect, QueryDict
from itu.Errror import PasswodException
import pymysql
from pymysql import err
import xml.etree.ElementTree as ET
import os
from itu.Decorator import Check_login, get_web_input_data
from ituface import conn
# 获取xml里数据
tree = ET.parse('./mysql_xml/insert_web.xml')
root = tree.getroot()
select = root.findall('select')
getXmlSql = lambda a: ''.join([i.text for i in select if i.get("id") == a]).strip()


def SelectSql(request):
    results = Students2.objects.all()

    paginator = Paginator(results, 10)
    page = request.GET.get('page', 1)
    a = [1, 2, 3]

    currentPage = int(page)
    try:
        print(page)
        result = paginator.page(page)
    except PageNotAnInteger:
        result = paginator.page(1)
    except EmptyPage:
        result = paginator.page(paginator.num_pages)

    return render(request, 'itufaceindex.html', {'SelectSql': results, 'page': str, 'paginator': paginator, 'bb': a})


# 登录页
def login(request):
    cookies = request.COOKIES.get('username')
    print(dict(request.POST))
    if request.method == 'POST':
        username = request.POST.get("username", None)
        password = request.POST.get('password', None)
        try:
            pwd = Students2.objects.get(user=username).password

            if pwd != password:
                try:
                    raise PasswodException
                except:
                    return render(request, 'login.html', {'message': '密码错误，请重新输入'})

        except:
            return render(request, 'login.html', {'message': '用户名错误，请重新输入'})

        if password == pwd:
            response = HttpResponseRedirect('/index/')
            response.set_cookie('username', username, 1800)
            return response
    if cookies != None:
        return redirect('/index/')

    return render(request, 'login.html')


# 首页
@Check_login
def index(request):
    username = request.COOKIES.get('username')

    return render(request, 'index.html', {'username': username})


# mysql数据
@get_web_input_data('web_mysql_data_user')
def member_list(request):
    cursor = conn.cursor(cursor=pymysql.cursors.DictCursor)
    print('request_POST------------------->', request.POST.get('sql'))
    datas = request.POST.get('sql')
    try:
        cursor.execute(datas)
        data = cursor.fetchall()
        conn.commit()
        print(data)

    except err.ProgrammingError as e:
        print(e)
        data = []

    except err.InternalError as e:
        print(e)
        data = []

    # 关闭游标
    cursor.close()
    # 关闭连接
    return render(request, 'member-list.html', {'data': data})


# 欢迎页面


def welcome(reqeust):
    return render(reqeust, "welcome.html", {'pathurl': '/fangjia.png'})


# Create your views here.


# 添加
def MemberAdd(request):
    if request.method == "POST":
        dictData = dict(request.POST)
        for key in dictData:
            if dictData[key] == '':
                return render(request, 'member-add.html', {dictData[key]: '不能为空'})
        userid = ''.join(dictData.get('user_id'))
        data = ''.join(dictData.get('data'))
        host = ''.join(dictData.get('host'))
        print('dictdata==============>', dictData)
        cursor = conn.cursor()
        sql_statement = getXmlSql('insert_user_id_data_host').format(user_id=userid, data=data, host=host)
        print('sql_statement------------>', sql_statement)
        try:
            result = cursor.execute(sql_statement)
            data = cursor.fetchall()
            print(data)
            conn.commit()

        except (err.ProgrammingError, err.IntegrityError, err.InternalError) as e:
            return render(request, 'member-add.html', {'errorid': '用户id不存在'})

        return render(request, 'member-add.html', {'success': '添加成功，可继续添加'})

    return render(request, 'member-add.html')


# 客户端管理/安装包上传下载

def OrderList(request):
    print(request.POST)
    return render(request, 'order-list.html')

#客户端上传
def OrderAdd(request):
    myFilemessage = ''
    if request.method=='POST':
        myFile=request.FILES.get('myfile')
        print('REQUSEST_POST----------------------->',request.POST)
        print('myFile=====================>',myFile)
        if not myFile:


            return render(request,'order-add.html',{'myFilemessage':'文件有误，请重新上传'})
        destination = open(os.path.join("./MyFile",myFile.name),'wb+')    # 打开特定的文件进行二进制的写操作
        print('writwritewritewritewritewritewritewritewritewritewritee')
        for chunk in myFile.chunks():  # 分块写入文件
            destination.write(chunk)
        destination.close()
        myFilemessage='上传成功'

    return render(request,'order-add.html',{'myFilemessage':myFilemessage})


def b():
    cursor = conn.cursor()
    result=cursor.execute('select * from data WHERE user_id=1')
    print(result)
b()
