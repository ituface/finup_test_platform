from django.http import HttpResponseRedirect,HttpResponse
from django.shortcuts import render_to_response,redirect,render

def logout(request):
   response=HttpResponseRedirect('/login/')
   response.delete_cookie('username')
   return response

#404页面
def notfound():
   return render_to_response('404.html')


#500页面
def page_error():
   return render_to_response('500.html')


#删除列表

def delete_member_list(request):
   print('r------------->------------->')
   print('request.get------------->',request.GET)
   if request.method=='get':
      id=request.GET['id']
      print('id--------------->',id)
   return  render(request,'    member-list.html')
