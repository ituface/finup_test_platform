import pymysql
from itu import TTs
pymysql.install_as_MySQLdb()
conn = pymysql.connect(host='127.0.0.1', port=int(3306), user='root', passwd='root123', db='yyy', charset='utf8')
