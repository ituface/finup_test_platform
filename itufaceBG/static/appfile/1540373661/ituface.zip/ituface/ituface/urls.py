"""ituface URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from Luoji import index,config
from api.apiT import User

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^login/',index.login),
    url(r'^index/$',index.index),
    url(r'member-list',index.member_list),
    url(r'welcome',index.welcome),
    url(r'^logout/',config.logout),
    url(r'^api/get',User.get),
    url(r'^api/post',User.post),
    url(r'member-add',index.MemberAdd),
    url(r'order-list',index.OrderList),
    url(r'order-add',index.OrderAdd),
    url(r'member-delete',config.delete_member_list),
]
