from django.views import View
from django.http import JsonResponse

from django.views.decorators.csrf import csrf_exempt

class User(View):
    @staticmethod
    def get(self, *args, **kwargs):
        result = {
            'status': True,
            'data': 'response data'
        }
        return JsonResponse(result, status=200)

    @csrf_exempt
    def post(self,request, *args, **kwargs):
        user=request.POST.get('user')
        result = {
            'status': True,
            'data': 'response data'
        }
        result['user']=user
        return JsonResponse(result, status=200)


